(function ($) {
"use strict";
$(document).ready(function () {
$(function () {

var windowheight    = $(window).height();
var windowWidth     = $(window).width();

/* --------------------------------------------------------------------- */
/* SCRIPT INIT
/* --------------------------------------------------------------------- */
  
  $(window).load(function(){
  
  $(function(){
    
    $.fn.center = function () {
      this.css("position","absolute");
      this.css("top", ( $(window).height() - this.height() ) / 2  + "px");
      this.css("left", ( $(window).width() - this.width() ) / 2 + "px");
      return this;
    }
    
    $(".potato-vCard-main").center(); 

    $(window).resize(function(){ 
       $(".potato-vCard-main").center();
    });

    
    
  });

});
  


/* --------------------------------------------------------------------- */
/* SKILL ANIMATION INIT
/* --------------------------------------------------------------------- */
$(document).ready(function() {

$('.single-skill-li').each(function() {
  $(this).closest('li').find('strong').text($(this).closest('li').attr('data-percentage')+'%');
});

$(".potato-single-content").hide();
$(".potato-single-content:first").show(); 
$("ul#potato-tabs-nav li").click(function() {
    $("ul#potato-tabs-nav li").removeClass("potato-active");
    $(this).addClass("potato-active");
    $(".potato-single-content").hide();
    var activeTab = $(this).attr("rel"); 
    $("#"+activeTab).fadeIn(); 


    $('#potato-tabs-3').scroll(function() {
        var areaHeight = $(this).height();

        
        $('.single-skill-li').each(function() {
            var top = $(this).position().top;
            var height = $(this).height();
            var data = $(this).closest('li').attr('data-percentage');
            var strong = $(this).closest('li').find('strong');

            if (top < areaHeight) {
              $(this).animate({width: data+'%'}, {duration: 5000, easing: 'easeOutCirc'});
            }
            
        });

        $('#ront-percentage').each(function() {
            var top = $(this).position().top;

            if (top < areaHeight) {
              $('.chart').easyPieChart();
            }
            
        });

    });


   
});
}); 



function loadGoogle() {
  var  map = new google.maps.Map(document.getElementById("map_canvas"), {
      center: new google.maps.LatLng(40.6700, -73.9400),
      zoom: 11,
      scrollwheel: false,
      navigationControl: false,
      mapTypeControl: false,
      scaleControl: false,
      draggable: true,
      disableDefaultUI: true,
      styles: [{"featureType":"all","elementType":"all","stylers":[{"saturation":-100},{"gamma":0.5}]}],
      mapTypeId: 'roadmap'
  });
  var marker = new google.maps.Marker({
    position: new google.maps.LatLng(40.6700, -73.9400),
    map: map,
    title: 'Potato vCard'
  });
  var contentString = '<div id="content">' +
      '<div id="myDiv">' +
      '</div>' +
      '<h3 id="heading">COLORADO</h3>' +
      '<div id="bodyContent">' +
      '<p>PIXIEFY THEMES ' +
      '2746 Scheuvront Drive ' +
      '<a href="#">www.pixiefy.com </a>' +
      'Denver, CO 80202 . </p>' +
      '</div>' +
      '</div>';

  var infowindow = new google.maps.InfoWindow({
      content: contentString,
      maxWidth: 280
  });

  marker.setAnimation(google.maps.Animation.BOUNCE);
  setTimeout(function(){ marker.setAnimation(null); }, 750);  //time it takes for one bounce   

  google.maps.event.addListener(marker, 'click', function () {
      infowindow.open(map, marker);
  });


}

$(document).ready(function(){
  var relID     =  $('#map_canvas').closest('.potato-single-content').attr('id');
  var element =  $("#potato-tabs-nav li[rel*='"+relID+"']");

  $( element ).click(function(){
    loadGoogle();
  });


$( '.grid li' ).click(function(){
  $('.potato-vCard-contant-container').css({'z-index': 3});
});
$( '.icon.nav-close' ).click(function(){
  $('.potato-vCard-contant-container').css({'z-index': 1});
});



});


/* --------------------------------------------------------------------- */
/* SCRIPT INIT
/* --------------------------------------------------------------------- */



});
});
})(jQuery);


(function ($) {
    "use strict";
    $(document).ready(function () {
        $(function () {

      /* --------------------------------------------------------------------- */
      /* ISOTOPE FILTER INIT
      /* --------------------------------------------------------------------- */

        $(window).load(function(){
          var $container = $('#da-thumbs');
          

          var $optionSets = $('#work-options .option-set'),
              $optionLinks = $optionSets.find('a');
          $optionLinks.click(function(){
          var $this = $(this);
            var $optionSet = $this.parents('.option-set');
            $optionSet.find('.selected').removeClass('selected');
            $this.addClass('selected');

            // make option object dynamically, i.e. { filter: '.my-filter-class' }
            var options = {},
                key = $optionSet.attr('data-option-key'),
                value = $this.attr('data-option-value');
            // parse 'false' as false boolean
            value = value === 'false' ? false : value;
            options[ key ] = value;
            if ( key === 'layoutMode' && typeof changeLayoutMode === 'function' ) {
              // changes in layout modes need extra logic
              changeLayoutMode( $this, options )
            } else {
              // creativewise, apply new options
              $container.isotope( options );
            }
            return false;
          }); 
        });


      });
    });
})(jQuery);



$(document).ready(function ($) {
  "use strict";
  $('#potato-tabs-1').perfectScrollbar();
  $('#potato-tabs-2').perfectScrollbar();
  $('#potato-tabs-3').perfectScrollbar();
  $('#potato-tabs-4').perfectScrollbar();
  $('#potato-tabs-5').perfectScrollbar();
  $('#potato-tabs-6').perfectScrollbar();
  $('.full-single-blog-page').perfectScrollbar();
});


